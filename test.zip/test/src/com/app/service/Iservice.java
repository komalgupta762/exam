package com.app.service;

import java.util.List;

import com.app.pojos.Vendor;


public interface Iservice {
	Vendor validate(String name,String password);
	List<Vendor> GetAll(Vendor v);
	String addvendor(Vendor v);
	String updateVendor(Vendor v);
	Vendor GetDetails(int id);
	 String delete(int id);
}
