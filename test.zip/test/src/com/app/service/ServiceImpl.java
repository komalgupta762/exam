package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.Ivendor;
import com.app.pojos.Vendor;
@Service
@Transactional
public class ServiceImpl implements Iservice {

	@Autowired
	private Ivendor dao;
	@Override
	public Vendor validate(String name, String password) {
		
		return dao.validate(name, password);
	}
	@Override
	public List<Vendor> GetAll(Vendor v) {
		// TODO Auto-generated method stub
		return dao.GetAll(v);
	}
	@Override
	public String addvendor(Vendor v) {
		// TODO Auto-generated method stub
		return dao.addvendor(v);
	}
	@Override
	public String updateVendor(Vendor v) {
		// TODO Auto-generated method stub
		return dao.updateVendor(v);
	}
	@Override
	public Vendor GetDetails(int id) {
		
		return dao.GetDetails(id);
	}
	@Override
	public String delete(int id) {
		
		return dao.delete(dao.GetDetails(id));
	}

}
