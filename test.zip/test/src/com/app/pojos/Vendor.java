package com.app.pojos;

import javax.persistence.*;

@Entity
@Table(name="vendor")
public class Vendor {
	Integer id;
	String name;
	String city;
	int mobile;
	String password;
	public Vendor() {
		// TODO Auto-generated constructor stub
	}

	


	public Vendor(String name, String city, int mobile, String password) {
		super();
		this.name = name;
		this.city = city;
		this.mobile = mobile;
		this.password = password;
	}


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Column(length = 20)
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	@Column(length = 20)
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
	@Column(length = 20)
	public int getMobile() {
		return mobile;
	}

	public void setMobile(int mobile) {
		this.mobile = mobile;
	}


	public String getPassword() {
		return password;
	}




	public void setPassword(String password) {
		this.password = password;
	}




	@Override
	public String toString() {
		return "vendor [id=" + id + ", name=" + name + ", city=" + city + ", mobile=" + mobile + ", password="
				+ password + "]";
	}

	

}
