package com.app.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.pojos.Vendor;
@Repository
public class vendorImpl implements Ivendor {

	@Autowired
	private SessionFactory sf;
	@Override
	public Vendor validate(String name, String password) {
		String jpql="select v from Vendor v where v.name=:nm and v.password=:pass";
		
		return sf.getCurrentSession().createQuery(jpql, Vendor.class).setParameter("nm", name).setParameter("pass", password).getSingleResult();
	}
	@Override
	public List<Vendor> GetAll(Vendor v) {
		String jpql="select v from Vendor v";
		return sf.getCurrentSession().createQuery(jpql,Vendor.class).getResultList();
	}
	@Override
	public String addvendor(Vendor v) {
	sf.getCurrentSession().save(v);
		return "added suuccessfuly";
	}
	@Override
	public String updateVendor(Vendor v) {
		sf.getCurrentSession().update(v);
		return "Vendor Updated";
	}
	@Override
	public Vendor GetDetails(int id) {
		// TODO Auto-generated method stub
		return sf.getCurrentSession().get(Vendor.class, id);
	}
	@Override
	public String delete(Vendor v) {
		
		 sf.getCurrentSession().delete(v);
		 return "deleted succesfully";
	}

}
