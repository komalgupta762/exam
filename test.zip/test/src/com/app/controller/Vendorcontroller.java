package com.app.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.app.pojos.Vendor;
import com.app.service.Iservice;

@Controller
@RequestMapping("/vendor")
public class Vendorcontroller {
	
	@Autowired
	private Iservice ser;
	
	@GetMapping("/login")
	public String showlogin()
	{
		return "/vendor/login";
	}
	
	@PostMapping("/login")
	public String processLogin(Model map,@RequestParam String name,@RequestParam String password,HttpSession hs)
	{
		try
		{
		Vendor v=ser.validate(name, password);
		map.addAttribute("status","login succesful");
		hs.setAttribute("vendor_detail", v);
		
		return "redirect:/vendor/list";
		}
		catch(RuntimeException e)
		{
			e.printStackTrace();
			return "/vendor/login";
		}
		
		
	}
	@GetMapping("/list")
	 public String GetAllVendor(Model map,Vendor v)
	{
		map.addAttribute("vendor_list",ser.GetAll(v));
		return "/vendor/list";
		
	}

	@GetMapping("/add")
	public String add()
	{
		return "/vendor/add";
	}
	@PostMapping("/add")
	public String processadd(Vendor v,RedirectAttributes flashmap)
	{
		
		flashmap.addFlashAttribute("add",ser.addvendor(v));
		return "redirect:/vendor/list";
	}
	@GetMapping("/update")
	public String Update(@RequestParam int id,Model map)
	{
		map.addAttribute("update",ser.GetDetails(id));
		return "/vendor/update";
	}
	
	@PostMapping("/update")
	public String UpdateProcess(Vendor v,RedirectAttributes flashmap)
	{
		flashmap.addFlashAttribute("update_v",ser.updateVendor(v));
		return "redirect:/vendor/list";
	}
	
	@GetMapping("/delete")
	public String delete(@RequestParam int id,RedirectAttributes flashmap)
	{
		flashmap.addFlashAttribute("deleted",ser.delete(id));
		return "/vendor/list";
		
		
	}
}
